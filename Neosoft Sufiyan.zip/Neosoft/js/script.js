const swiperSlide = document.querySelectorAll('.swiper-slide');

swiperSlide.forEach(function(el){
  el.addEventListener('mouseenter', function(){
    swiper.autoplay.stop();
  });
  el.addEventListener('mouseleave', function(){
    swiper.autoplay.start();
  });
})

// swiperSlide.addEventListener('mouseenter', function(){
//   swiper.autoplay.stop();
// });
// swiperSlide.addEventListener('mouseleave', function(){
//   swiper.autoplay.start();
// });


const searchBtn = document.querySelector('.search-icon');

searchBtn.addEventListener('click', function(){
  document.getElementById("myNav").style.height = "100%";
});

const closeBtn = document.querySelector('.closebtn');

closeBtn.addEventListener('click', function(){
  document.getElementById("myNav").style.height = "0%";
});



const menuBtn = document.querySelector('.menu-btn');

menuBtn.addEventListener('click', function(){
  document.getElementById("myMobileNav").style.width = "100%";
});

const closeMenu = document.querySelector('.closebtn-mobile');

closeMenu.addEventListener('click', function(){
  document.getElementById("myMobileNav").style.width = "0%";
})

// Header Fix

window.onscroll = function() {myFunction()};

var header = document.getElementById("myHeader");
var sticky = header.offsetTop;

function myFunction() {
  if (window.pageYOffset > sticky) {
    header.classList.add("fixed-header");
  } else {
    header.classList.remove("fixed-header");
  }
};

const scrollBtn = document.querySelector('.scroll-btn');

scrollBtn.addEventListener('click', function(){
  var element = document.querySelector(".aboutSection");

  // smooth scroll to element and align it at the bottom
  element.scrollIntoView({ behavior: 'smooth', block: 'end'});
})